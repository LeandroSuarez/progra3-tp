public class Dimension {
    public int filas;
    public int columnas;

    public Dimension(int filas, int columnas) {
        this.filas = filas;
        this.columnas = columnas;
    }
}
